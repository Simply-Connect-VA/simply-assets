﻿# phpVMS ACARS

# Requirements

- .NET 4.7 Runtime
- Prepar3d
  - MakeRwys (from Pete Dowson http://fsuipc.simflight.com/beta/MakeRwys.zip)
- X-Plane with plugin below

# Installation (For VA Owners)

## phpVMS Module

### phpVMS 7

Copy the folder in `Web/v7` into your `/modules` folder in your phpVMS install.
Then to go `/update` in your browser to complete the setup.

### phpVMS Legacy

Copy the folder in `Web/legacy` into your `core/modules` folder. There is no install required for this one.

## ACARS Application

### Installation

Extract the zip file to any directory wherever you want it to run.

```
My Documents/phpVMS
```

A test update might require deleting these files and redoing your settings.

### Running

On first start, you'll be taken to the Settings page - fill out the information here. Set your VA
web address, and then your API key from your profile. Set the path to either P3D or X-Plane, press
save and then it will resync the scenery.

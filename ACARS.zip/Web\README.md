# phpVMS ACARS Module

There are two versions of the ACARS module... legacy and v7

# v7 Install

Place the `VMSACARS` folder from the `v7` folder into your `/modules` directory. Then go to your site and run the update:

```
http://yourphpvmssite.net/update
```

It will add the database tables. You'll then have an option in the admin panel for configuration.

# Legacy install

Copy the `API` folder from the `legacy` folder and place it into your `core/modules` directory. There is no database component, all of the configuration is done in the `API/config.php` file (sorry!)

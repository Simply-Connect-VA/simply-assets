<?php
/**
 * Copyright (C) phpVMS - All Rights Reserved
 * Unauthorized copying or distribution of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Nabeel Shahzad <nabeel@phpvms.net>
 */

require_once __DIR__.'/converter.php';
require_once __DIR__.'/helpers.php';
require_once __DIR__.'/models.php';
require_once __DIR__.'/service.php';

/**
 *
 */
class API extends CodonModule
{
    private $api_key;
    private $config;
    private $converter;
    private $svc;
    private $pagination;
    private $user;
    private $method;
    private $rules;

    public static $PAGINATION_SIZE = 25;

    /**
     * API constructor.
     * @throws Exception
     */
    public function __construct()
    {
        parent::__construct();
        $this->config = require __DIR__.'/config.php';
        $this->rules = require __DIR__.'/rules.php';

        $this->converter = new ApiConverter();
        $this->svc = new ApiService();
    }

    /**
     *
     */
    public function __call($name, $args)
    {
        try {
            $this->__init();
        } catch (ErrorException $e) {
            return $this->handleError($e->code, $e->message);
        }

        $data = [];
        $request = $this->parseArgs($args);
        $this->pagination = $this->getPagination();

        try {
            switch ($name) {
                case 'airlines':
                    $data = $this->airlines();
                    break;
                case 'config':
                    break;
                case 'flights':
                    $data = $this->flights();
                    break;
                case 'pireps':

                    # Specific actions on the PIREPs
                    if ($request['action'] === 'prefile') {
                        $data = $this->pirep_prefile();
                    } else if ($request['action'] === 'update') {
                        $data = $this->pirep_update($request['id']);
                    } else if ($request['action'] === 'fields') {
                        $data = $this->pirep_fields($request['id']);
                    } else if ($request['action'] === 'route') {
                        $data = [];  // doesn't do anything atm
                    } else if ($request['action'] === 'file') {
                        $data = $this->pirep_file($request['id']);
                    } else if ($request['action'] === 'cancel') {
                        $data = $this->pirep_cancel($request['id']);
                    }

                    # ACARS updates
                    else if ($request['action'] === 'acars/positions') {
                        $data = $this->acars_position($request['id']);
                    } else if ($request['action'] === 'acars/logs') {
                        $data = $this->acars_log($request['id']);
                    }

                    else {
                        //var_dump($request);
                        $data = $this->pirep_get($request['action']);
                    }

                    break;

                case 'rules':
                    $data = $this->rules();
                    break;

                case 'user':
                    if ($request['action'] === 'bids') {
                        $data = $this->bids();
                    } else {
                        $data = $this->user();
                    }

                    break;
                default:
                    header('HTTP/1.1 404 Not Found');
                    return;
                    break;
            }
        } catch (ErrorException $e) {
            return $this->handleError($e->getCode(), $e->getMessage());
        }

        if($data !== null)
            $this->write_data($data);

        return true;
    }

    /** @noinspection MagicMethodsValidityInspection */
    /**
     *
     * @throws ErrorException
     */
    private function __init()
    {
        $this->method = strtolower($_SERVER['REQUEST_METHOD']);

        // For now, just use the user's pilot ID as the API key
        $headers = getallheaders();
        $this->api_key = $headers['X-Api-Key'];
        if (!$this->api_key || $this->api_key === '')
            $this->api_key = $headers['x-api-key'];

        if (!$this->api_key || $this->api_key === '')
            throw new ErrorException('No API Key', 401);

        if (!$this->validateUser()) {
            throw new ErrorException('Invalid User', 401);
        }
    }

    /**
     *
     */
    private function handleError($code, $message)
    {
        header('HTTP/1.1 '.$code);
        header('Content-type:application/json;charset=utf-8');

        $e = [
            'error' => [
                'code'    => $code,
                'message' => $message,
            ]
        ];

        echo json_encode($e);
    }

    /**
     *
     * @throws ErrorException
     */
    private function validateUser()
    {
        $id = $this->svc->getUserId($this->api_key);
        $this->user = PilotData::getPilotData($id);
        $this->user->id = $this->user->pilotid;
        if (!$this->user) {
            return false;
        }

        return true;
    }

    /**
     *
     */
    private function parseArgs($args)
    {
        $len = count($args);
        if ($len === 0) {
            return [];
        }

        if ($len === 1) {
            return ['action' => $args[0]];
        }

        $id = $args[0];
        $action = implode('/', array_slice($args, 1));

        return [
            'action' => $action,
            'id'     => $id,
        ];
    }

    /**
     *
     * @throws ErrorException
     */
    private function parseBody()
    {
        try {
            $input = file_get_contents('php://input');
            return json_decode($input);
        } catch (Exception $e) {
            throw new ErrorException('Invalid input', 400);
        }
    }

    /**
     *
     */
    private function getPagination()
    {
        $page = 1;
        if (array_key_exists('page', $_GET)) {
            $page = $_GET['page'];
        }

        return [
            'page'  => $page,
            'start' => ($page - 1) * static::$PAGINATION_SIZE,
            'count' => static::$PAGINATION_SIZE
        ];
    }

    /**
     * Standardized output
     * @param      $message
     * @param null $count
     */
    private function write_message($message, $count = null)
    {
        $attrs = [
            'message' => $message
        ];

        if ($count !== null) {
            $attrs['count'] = $count;
        }

        $this->write($attrs);
    }

    /**
     * Dump something out to JSON
     * @param $obj
     */
    private function write_data($obj)
    {
        $total = 1;
        if (is_array($obj)) {
            $total = count($obj);
        }

        $this->write([
            'data'  => $obj,
            // fake out other parts of the response that might be needed
            'links' => [],
            'meta'  => [
                'current_page' => $this->pagination['page'],
                'last_page'    => 1,
                'total'        => $total,
                'per_page'     => $this->pagination['count'],
            ]
        ]);
    }

    /**
     * Write out to JSON
     * @param $obj
     */
    private function write($obj)
    {
        header('Content-type:application/json;charset=utf-8');
        echo json_encode($obj);
    }

    /**
     * Position update for ACARS. Comes as a list
     * @throws ErrorException
     */
    private function acars_log($pirep_id)
    {
        if ($this->method !== 'post') {
            throw new ErrorException('Only POST', 400);
        }

        $req = $this->parseBody();
        $logs = $req->logs;
        $count = count($logs);

        foreach ($logs as $log) {
            PIREPData::addComment($pirep_id, $this->user->id, $log->log);
        }

        $this->write_message($count.' logs added', $count);
        return null;
    }

    /**
     * Position update for ACARS. Comes as a list
     * @throws ErrorException
     */
    private function acars_position($pirep_id)
    {
        if ($this->method !== 'post') {
            throw new ErrorException('Only POST', 400);
        }

        $pirep = PIREPData::getReportDetails($pirep_id);
        if(!$pirep) {
            throw new ErrorException('PIREP not found', 404);
        }

        /*
        Incoming
        {
            "positions": [
                {
                    "pirep_id": null,
                    "airline_id": 1,
                    "aircraft_id": 1,
                    "flight_number": 123,
                    "log":"Position Update",
                    "lat":-56.332655,
                    "lon":0.444645,
                    "distance":4240.38,
                    "heading":232,
                    "altitude":170,
                    "vs":-3006,
                    "gs":418,
                    "transponder":8044,
                    "autopilot":"Eum et.",
                    "fuel":776.91,
                    "fuel_flow":822.07,
                    "status": "",
                    "sim_time":"{% now 'iso-8601', '' %}",
                    "created_at":"{% now 'iso-8601', '' %}"
                }
            ]
        }
        */

        $req = $this->parseBody();
        $positions = $req->positions;
        $count = count($positions);

        $this->svc->sortByDateTime($positions);

        // Only pull the last update
        $pos = array_pop($positions);

        $fields = [
            'pilotid'     => $this->user->id,
            'flightnum'   => $pirep->code.$pirep->flightnum,
            'pilotname'   => $this->user->firstname.' '.$this->user->lastname,
            'aircraft'    => $pirep->aircraft,
            'depicao'     => $pirep->depicao,
            'arricao'     => $pirep->arricao,
            'lat'         => $pos->lat,
            'lng'         => $pos->lon,
            'heading'     => $pos->heading,
            'alt'         => $pos->altitude,
            'gs'          => $pos->gs,
            'distremain'  => $pos->distance,
            'phasedetail' => $this->config['phases'][$pos->phase],
            'client'      => 'VMSAcars',
            'online'      => '',
            // 'deptime'        => $xml->liveupdate->depTime,
            // 'arrtime'        =>' ',
            // 'route'          => $xml->liveupdate->route,
            // 'distremain'     => $dist_remain,
            // 'timeremaining'  => $time_remain,
            // 'online'         => '',
            // 'client'         => 'kACARS',
        ];

        ACARSData::updateFlightData($this->user->id, $fields);

        $this->write_message($count.' positions added', $count);
        return null;
    }

    /**
     * Get the aircraft. Fake having subfleets.
     */
    private function aircraft()
    {
        $aircraft = OperationsData::getAllAircraft(true);
        return [
            'subfleets' => $this->converter->subfleet($aircraft),
        ];
    }

    /**
     * Return the airlines
     */
    private function airlines()
    {
        $obj = [];

        $airlines = OperationsData::getAllAirlines(true);
        foreach ($airlines as $airline) {
            $obj[] = $this->converter->airline($airline);
        }

        return $obj;
    }

    /**
     *
     */
    private function bids()
    {
        $bids = [];
        $aircraft = [];
        $airlines = [];
        $bid_data = SchedulesData::getBids($this->user->id);
        if ($bid_data) {
            foreach ($bid_data as $bid) {
                if (!array_key_exists($bid->code, $airlines)) {
                    $al = OperationsData::getAirlineByCode($bid->code);
                    $airlines[$bid->code] = $this->converter->airline($al);
                }

                if (!array_key_exists($bid->registration, $aircraft)) {
                    $ac = OperationsData::getAircraftByReg($bid->registration);
                    $aircraft[$bid->registration] = $ac;
                }

                $flight = $this->converter->schedule($bid);
                $flight['airline'] = $airlines[$bid->code];
                $flight['subfleets'] = $this->converter->subfleet($aircraft);

                $sched = [
                    'id'        => $bid->bidid,
                    'flight_id' => $flight['id'],
                    'user_id'   => $this->user->id,
                    'flight'    => $flight,
                ];

                $bids[] = $sched;
            }
        }

        return $bids;
    }

    /**
     *
     */
    private function flights()
    {
        $obj = [];

        $page = $this->getPagination();
        $schedules = SchedulesData::findSchedules(
            [],
            $this->pagination['count'],
            $this->pagination['start']);

        $airlines = [];
        $aircraft = [];
        foreach ($schedules as $s) {
            if(!array_key_exists($s->code, $airlines)) {
                $al = OperationsData::getAirlineByCode($s->code);
                $airlines[$s->code] = $this->converter->airline($al);
            }

            if (!array_key_exists($s->registration, $aircraft)) {
                $ac = OperationsData::getAircraftByReg($s->registration);
                $aircraft[$s->registration] = $ac;
            }

            $sched = $this->converter->schedule($s);
            $sched['airline'] = $airlines[$s->code];
            $sched['subfleets'] = $this->converter->subfleet($aircraft);
            $obj[] = $sched;
        }

        return $obj;
    }

    /**
     *
     */
    private function pirep_get($pirep_id)
    {
        return $this->svc->pirep_legacy_to_v7($pirep_id);
    }

    /**
     *
     * @throws ErrorException
     */
    private function pirep_prefile()
    {
        $req = $this->parseBody();
        $req->pilot_id = $this->user->id;
        return $this->svc->pirep_prefile($req);
    }

    /**
     *
     * @throws ErrorException
     */
    private function pirep_update($pirep_id)
    {
        $req = $this->parseBody();
        $req->pilot_id = $this->user->id;
        return $this->svc->pirep_update($pirep_id, $req);
    }

    /**
     *
     * @param $pirep_id
     * @return array
     * @throws ErrorException
     */
    private function pirep_fields($pirep_id)
    {
        $req = $this->parseBody();
        $this->svc->update_fields($pirep_id, $req->fields);
        return $this->svc->pirep_legacy_to_v7($pirep_id);
    }

    /**
     *
     * @param $pirep_id
     * @return array
     * @throws ErrorException
     */
    private function pirep_file($pirep_id)
    {
        $req = $this->parseBody();
        $req->pilot_id = $this->user->id;
        return $this->svc->pirep_file($pirep_id, $req);
    }

    /**
     * Cancel the pirep
     * @param $pirep_id
     * @return array
     * @throws ErrorException
     */
    private function pirep_cancel($pirep_id)
    {
        $this->parseBody();

        $this->svc->pirep_cancel($pirep_id);
        $this->write_message('PIREP cancelled');
        return null;
    }

    /**
     * Show all of the rules
     */
    private function rules()
    {
        $obj = [];
        foreach ($this->rules as $rule) {
            if (!$rule['enabled']) {
                continue;
            }

            $obj[] = [
                'id'            => $rule['id'],
                'parameter'     => $rule['parameter'],
                'points'        => $rule['points'],
                'has_parameter' => $rule['has_parameter'],
            ];
        }

        return $obj;
    }

    /**
     * @return array
     */
    private function user()
    {
        /*
         * {
            "data": {
                "id": 1,
                "pilot_id": "VMS0001",
                "name": "Admin User",
                "email": "admin@phpvms.net",
                "apikey": null,
                "rank_id": 1,
                "home_airport": "KAUS",
                "curr_airport": "KJFK",
                "last_pirep_id": "pirepid_3",
                "flights": null,
                "flight_time": 0,
                "balance": null,
                "timezone": "America\/Chicago",
                "status": 0,
                "state": 1,
                "airline": {
                    "id": 1,
                    "icao": "VMS",
                    "iata": "VM",
                    "name": "phpvms airlines",
                    "country": "us",
                    "logo": null
                },
                "bids": [
                    {
                        "id": 101,
                        "user_id": 1,
                        "flight_id": "flightid_3"
                    }
                ],
                "rank": {
                    "name": "New Pilot",
                    "subfleets": [
                 */

        $airline = OperationsData::getAirlineByCode($this->user->code);

        $curr = PIREPData::getLastReports($this->user->id, 1);
        if($curr) {
            $curr = $curr->arricao;
        }

        #  get any bids
        $bids = $this->bids();

        $obj = [
            'id'   => $this->user->id,
            'name' => $this->user->firstname.' '.$this->user->lastname,
            'home_airport' => $this->user->hub,
            'curr_airport' => $curr,
            'airline' => $this->converter->airline($airline),
            'bids' => $bids,
            'rank' => [
                'name'      => $this->user->rank,
                'subfleets' => [],
            ],
        ];

        // get aircraft
        $obj['rank']['subfleets'] = $this->aircraft()['subfleets'];

        return $obj;
    }
}

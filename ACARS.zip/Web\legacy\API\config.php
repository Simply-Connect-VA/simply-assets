<?php
/**
 * Copyright (C) phpVMS - All Rights Reserved
 * Unauthorized copying or distribution of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Nabeel Shahzad <nabeel@phpvms.net>
 */

return [
    /**
     * ACARS states
     */
    'phases' => [
        'INI' => 'Initiated',
        'SCH' => 'Scheduled',
        'BST' => 'Boarding',
        'RDT' => 'Ready for start',
        'PBT' => 'Pushback/towing',
        'OFB' => 'Departed',
        'DIR' => 'Ready for de-icing',
        'DIC' => 'De-icing in progress',
        'GRT' => 'Ground return',
        'TXI' => 'Taxi',
        'TOF' => 'Takeoff',
        'ICL' => 'Initial Climb',
        'TKO' => 'Enroute',
        'ENR' => 'Enroute',
        'DV'  => 'Diverted',
        'TEN' => 'Final approach',
        'APR' => 'Final approach',
        'FIN' => 'Landed',
        'LDG' => 'Landing',
        'LAN' => 'Landed',
        'ONB' => 'Arrived',
    ]
];

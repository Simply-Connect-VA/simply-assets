<?php
/**
 * Provide any configuration items here
 */

/*return [
    'name'        => 'VMSAcars',
    'license_url' => 'https://vmshost.io',
];*/

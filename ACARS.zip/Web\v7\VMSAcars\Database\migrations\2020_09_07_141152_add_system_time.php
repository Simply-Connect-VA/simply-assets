<?php

use Modules\VMSAcars\Contracts\Migration;

class AddSystemTime extends Migration
{
    public function up()
    {
        $this->seedFile('settings.yml');
    }

    public function down()
    {

    }
}

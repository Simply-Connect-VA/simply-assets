<?php

use Modules\VMSAcars\Contracts\Migration;

class AddFareRequiredSetting extends Migration
{
    public function up()
    {
        $this->seedFile('settings.yml');
    }

    public function down()
    {

    }
}

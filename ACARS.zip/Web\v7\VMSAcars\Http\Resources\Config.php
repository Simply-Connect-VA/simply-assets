<?php

namespace Modules\VMSAcars\Http\Resources;

use App\Contracts\Resource;

class Config extends Resource
{
}


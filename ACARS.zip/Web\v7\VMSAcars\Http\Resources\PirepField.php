<?php

namespace Modules\VMSAcars\Http\Resources;

use App\Contracts\Resource;

class PirepField extends Resource
{
}

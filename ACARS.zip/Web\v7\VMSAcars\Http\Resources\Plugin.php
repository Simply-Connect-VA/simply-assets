<?php

namespace Modules\VMSAcars\Http\Resources;

use App\Contracts\Resource;

class Plugin extends Resource
{
    public function toArray($request)
    {
        return [

        ];
    }
}


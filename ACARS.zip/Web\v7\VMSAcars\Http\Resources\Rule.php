<?php

namespace Modules\VMSAcars\Http\Resources;

use App\Contracts\Resource;

class Rule extends Resource
{
    /*public function toArray($request)
    {
        return [
            'id' => $this->id,
            'parameter' => $this->parameter,
            'points' => $this->points,
            'has_parameter' => $this->has_parameter,
        ];
    }*/
}

